//Example 1: HelloWorld.java
//Text-printing program
public class HelloWorld {

    public static void main(String[] args) {
        //In "Xin chào thế giới!"
        System.out.println("Xin chào thế giới!");
        //In "Hello world!"
        System.out.println("Hello world!");
    }
}
